// @bun
var __require = import.meta.require;

// src/index.ts
import fs4 from "fs";
import os2 from "os";
import path4 from "path";

// src/log.ts
import fs from "fs";

// src/paths.ts
import { createHash } from "crypto";
import os from "os";
import path from "path";
function dataDir() {
  const xdg = process.env["XDG_DATA_HOME"] ?? path.join(os.homedir(), ".local", "share");
  return path.join(xdg, "opencode");
}
function stateBaseDir() {
  return process.env["OPENCODE_GIT_SYNC_DIR"] ?? path.join(dataDir(), "git-sync");
}
var stateDirOverride;
function setStateDir(dir) {
  stateDirOverride = dir;
}
function stateDir() {
  return stateDirOverride ?? stateBaseDir();
}
function projectKey(worktree) {
  const resolved = path.resolve(worktree);
  const name = path.basename(resolved).replace(/[^a-zA-Z0-9._-]/g, "-") || "root";
  const hash = createHash("sha256").update(resolved).digest("hex").slice(0, 8);
  return `${name}-${hash}`;
}
function projectStateDir(worktree) {
  return path.join(stateBaseDir(), projectKey(worktree));
}
function repoDir() {
  return path.join(stateDir(), "repo");
}
function stateDbPath() {
  return path.join(stateDir(), "state.db");
}
function logPath() {
  return path.join(stateDir(), "git-sync.log");
}
function defaultPassphraseFiles() {
  const configDir = process.env["XDG_CONFIG_HOME"] ?? path.join(os.homedir(), ".config");
  return [
    path.join(configDir, "opencode", "git-sync.key"),
    path.join(configDir, "opencode", "git-sync.passphrase")
  ];
}
async function findOpencodeDb() {
  const explicit = process.env["OPENCODE_DB"];
  if (explicit) {
    if (explicit === ":memory:")
      return;
    return path.isAbsolute(explicit) ? explicit : path.join(dataDir(), explicit);
  }
  const dir = dataDir();
  const names = ["opencode.db"];
  try {
    const { readdir } = await import("fs/promises");
    for (const entry of await readdir(dir)) {
      if (entry.startsWith("opencode") && entry.endsWith(".db") && !names.includes(entry))
        names.push(entry);
    }
  } catch {
    return;
  }
  const candidates = [];
  const { stat } = await import("fs/promises");
  for (const name of names) {
    const file = path.join(dir, name);
    try {
      const info = await stat(file);
      candidates.push({ file, mtime: info.mtimeMs });
    } catch {
      continue;
    }
  }
  candidates.sort((a, b) => b.mtime - a.mtime);
  return candidates[0]?.file;
}

// src/log.ts
var LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };
var threshold = LEVELS[process.env["OPENCODE_GIT_SYNC_LOG"]] ?? LEVELS.warn;
function write(level, message) {
  if (LEVELS[level] < threshold)
    return;
  const line = `${new Date().toISOString()} [${level}] ${message}`;
  try {
    fs.mkdirSync(stateDir(), { recursive: true });
    fs.appendFileSync(logPath(), line + `
`);
  } catch {}
  if (level === "error" || level === "warn")
    console.error(`[git-sync] ${message}`);
}
var log = {
  debug: (message) => write("debug", message),
  info: (message) => write("info", message),
  warn: (message) => write("warn", message),
  error: (message) => write("error", message)
};

// src/git.ts
import { spawn } from "child_process";
var BASE_ENV = {
  GIT_TERMINAL_PROMPT: "0",
  GIT_ASKPASS: "/bin/true",
  GIT_SSH_COMMAND: "ssh -o BatchMode=yes -o ConnectTimeout=5 -o StrictHostKeyChecking=accept-new",
  GIT_CONFIG_NOSYSTEM: "1",
  LC_ALL: "C"
};
function gitEnv(extra) {
  return { ...process.env, ...BASE_ENV, ...extra };
}
function git(args, opts) {
  const timeoutMs = opts.timeoutMs ?? 8000;
  return new Promise((resolve) => {
    const child = spawn("git", args, {
      cwd: opts.cwd,
      env: gitEnv(opts.env),
      stdio: ["ignore", "pipe", "pipe"]
    });
    let stdout = "";
    let stderr = "";
    let settled = false;
    const timer = setTimeout(() => {
      if (settled)
        return;
      settled = true;
      child.kill("SIGKILL");
      resolve({ code: 124, stdout, stderr: `timeout after ${timeoutMs}ms` });
    }, timeoutMs);
    child.stdout?.on("data", (chunk) => {
      stdout += chunk.toString();
    });
    child.stderr?.on("data", (chunk) => {
      stderr += chunk.toString();
    });
    child.on("error", (error) => {
      if (settled)
        return;
      settled = true;
      clearTimeout(timer);
      resolve({ code: 127, stdout, stderr: String(error) });
    });
    child.on("close", (code) => {
      if (settled)
        return;
      settled = true;
      clearTimeout(timer);
      resolve({ code: code ?? 1, stdout, stderr });
    });
  });
}
async function gitOrThrow(args, opts) {
  const result = await git(args, opts);
  if (result.code !== 0) {
    throw new Error(`git ${args.join(" ")} \u5931\u8D25(${result.code}): ${result.stderr.trim() || result.stdout.trim()}`);
  }
  return result;
}
async function readBlobs(shas, opts) {
  const result = new Map;
  if (shas.length === 0)
    return result;
  const unique = [...new Set(shas)];
  const payload = await new Promise((resolve) => {
    const child = spawn("git", ["cat-file", "--batch"], {
      cwd: opts.cwd,
      env: gitEnv(),
      stdio: ["pipe", "pipe", "pipe"]
    });
    const chunks = [];
    let stderr = "";
    let settled = false;
    const timer = setTimeout(() => {
      if (settled)
        return;
      settled = true;
      child.kill("SIGKILL");
      resolve({ stdout: Buffer.concat(chunks), stderr: "timeout", code: 124 });
    }, opts.timeoutMs ?? 15000);
    child.stdout?.on("data", (chunk) => chunks.push(chunk));
    child.stderr?.on("data", (chunk) => {
      stderr += chunk.toString();
    });
    child.on("error", (error) => {
      if (settled)
        return;
      settled = true;
      clearTimeout(timer);
      resolve({ stdout: Buffer.concat(chunks), stderr: String(error), code: 127 });
    });
    child.on("close", (code) => {
      if (settled)
        return;
      settled = true;
      clearTimeout(timer);
      resolve({ stdout: Buffer.concat(chunks), stderr, code: code ?? 1 });
    });
    for (const sha of unique)
      child.stdin?.write(sha + `
`);
    child.stdin?.end();
  });
  if (payload.code !== 0) {
    log.warn(`git cat-file --batch \u5931\u8D25: ${payload.stderr.trim()}`);
    return result;
  }
  let offset = 0;
  const buffer = payload.stdout;
  while (offset < buffer.length) {
    const headerEnd = buffer.indexOf(10, offset);
    if (headerEnd < 0)
      break;
    const header = buffer.subarray(offset, headerEnd).toString("utf8").trim();
    offset = headerEnd + 1;
    const parts = header.split(/\s+/);
    const sha = parts[0] ?? "";
    const size = Number(parts[2] ?? "0");
    if (!Number.isFinite(size) || size < 0)
      break;
    const body = buffer.subarray(offset, offset + size);
    offset += size + 1;
    if (body.length < size)
      break;
    result.set(sha, Buffer.from(body));
  }
  return result;
}

// src/remote.ts
async function detectRemote(worktree, timeoutMs = 8000) {
  const origin = await git(["remote", "get-url", "origin"], { cwd: worktree, timeoutMs });
  const url = origin.stdout.trim();
  if (origin.code === 0 && url)
    return url;
  const remotes = await git(["remote"], { cwd: worktree, timeoutMs });
  if (remotes.code !== 0)
    return;
  const first = remotes.stdout.split(`
`).map((line) => line.trim()).find((line) => line.length > 0);
  if (!first)
    return;
  const fallback = await git(["remote", "get-url", first], { cwd: worktree, timeoutMs });
  const value = fallback.stdout.trim();
  if (fallback.code !== 0 || !value) {
    log.warn(`\u9879\u76EE\u4ED3\u5E93\u6CA1\u6709\u53EF\u7528\u8FDC\u7AEF\uFF08${worktree}\uFF09`);
    return;
  }
  return value;
}

// src/ocdb.ts
import { Database } from "bun:sqlite";

class OpencodeDb {
  db;
  sessionColumns = new Set;
  messageColumns = new Set;
  partColumns = new Set;
  constructor(file) {
    this.db = new Database(file);
    this.db.run("PRAGMA busy_timeout = 5000;");
    this.sessionColumns = this.columns("session");
    this.messageColumns = this.columns("message");
    this.partColumns = this.columns("part");
  }
  columns(table) {
    try {
      const rows = this.db.query(`PRAGMA table_info(${table})`).all();
      return new Set(rows.map((row) => row.name));
    } catch {
      return new Set;
    }
  }
  hasSession(sessionID) {
    const row = this.db.query("SELECT id FROM session WHERE id = ?").get(sessionID);
    return row !== null && row !== undefined;
  }
  transaction(fn) {
    return this.db.transaction(fn)();
  }
  sessionUpdatedAt(sessionID) {
    const row = this.db.query("SELECT time_updated FROM session WHERE id = ?").get(sessionID);
    return typeof row?.time_updated === "number" ? row.time_updated : undefined;
  }
  upsertSession(meta, scope) {
    const existing = this.db.query("SELECT time_updated, title FROM session WHERE id = ?").get(meta.id);
    const localUpdated = typeof existing?.time_updated === "number" ? existing.time_updated : undefined;
    const remoteUpdated = meta.time.updated;
    if (existing && localUpdated !== undefined && remoteUpdated <= localUpdated)
      return false;
    const row = {
      id: meta.id,
      project_id: scope.projectID,
      directory: scope.directory,
      path: scope.path,
      title: meta.title,
      slug: meta.slug ?? slugFallback(meta.id),
      version: meta.version ?? "unknown",
      parent_id: meta.parentID ?? null,
      time_created: meta.time.created,
      time_updated: remoteUpdated
    };
    if (meta.agent !== undefined)
      row["agent"] = meta.agent;
    if (meta.model !== undefined)
      row["model"] = JSON.stringify(meta.model);
    if (meta.cost !== undefined)
      row["cost"] = meta.cost;
    if (meta.summary !== undefined)
      row["summary_additions"] = numberField(meta.summary, "additions");
    if (meta.tokens !== undefined) {
      row["tokens_input"] = numberField(meta.tokens, "input");
      row["tokens_output"] = numberField(meta.tokens, "output");
      row["tokens_reasoning"] = numberField(meta.tokens, "reasoning");
    }
    if (!existing) {
      const columns2 = Object.keys(row).filter((key) => this.sessionColumns.size === 0 || this.sessionColumns.has(key));
      const sql = `INSERT OR IGNORE INTO session (${columns2.join(", ")}) VALUES (${columns2.map((column) => `$${column}`).join(", ")})`;
      this.db.run(sql, columns2.map((column) => row[column] ?? null));
      return true;
    }
    const updatable = {
      title: meta.title,
      time_updated: remoteUpdated
    };
    if (meta.agent !== undefined)
      updatable["agent"] = meta.agent;
    if (meta.model !== undefined)
      updatable["model"] = JSON.stringify(meta.model);
    const columns = Object.keys(updatable).filter((key) => this.sessionColumns.has(key));
    if (columns.length === 0)
      return false;
    this.db.run(`UPDATE session SET ${columns.map((column) => `${column} = ?`).join(", ")} WHERE id = ?`, [...columns.map((column) => updatable[column]), meta.id]);
    return true;
  }
  upsertMessage(sessionID, info, parts) {
    const { id: messageID, sessionID: _sessionID, ...messageData } = info;
    const timeCreated = typeof info.time?.created === "number" ? info.time.created : Date.now();
    const data = JSON.stringify(messageData);
    const existing = this.db.query("SELECT data FROM message WHERE id = ?").get(messageID);
    const changed = !existing || existing.data !== data;
    if (!existing) {
      const columns = ["id", "session_id", "time_created", "time_updated", "data"].filter((column) => this.messageColumns.size === 0 || this.messageColumns.has(column));
      this.db.run(`INSERT OR IGNORE INTO message (${columns.join(", ")}) VALUES (${columns.map((c) => `$${c}`).join(", ")})`, columns.map((column) => column === "id" ? messageID : column === "session_id" ? sessionID : column === "time_created" ? timeCreated : column === "time_updated" ? timeCreated : data));
    } else if (changed) {
      this.db.run("UPDATE message SET data = ?, time_updated = ? WHERE id = ?", [data, Date.now(), messageID]);
    }
    let partsChanged = false;
    for (const part of parts) {
      const { id: partID, sessionID: _s, messageID: _m, ...partData } = part;
      const partJson = JSON.stringify(partData);
      const existingPart = this.db.query("SELECT data FROM part WHERE id = ?").get(partID);
      if (!existingPart) {
        const columns = ["id", "message_id", "session_id", "time_created", "time_updated", "data"].filter((column) => this.partColumns.size === 0 || this.partColumns.has(column));
        this.db.run(`INSERT OR IGNORE INTO part (${columns.join(", ")}) VALUES (${columns.map((c) => `$${c}`).join(", ")})`, columns.map((column) => column === "id" ? partID : column === "message_id" ? messageID : column === "session_id" ? sessionID : column === "time_created" ? timeCreated : column === "time_updated" ? timeCreated : partJson));
        partsChanged = true;
      } else if (existingPart.data !== partJson) {
        this.db.run("UPDATE part SET data = ?, time_updated = ? WHERE id = ?", [partJson, Date.now(), partID]);
        partsChanged = true;
      }
    }
    return changed || partsChanged;
  }
  close() {
    try {
      this.db.close();
    } catch {}
  }
}
function slugFallback(sessionID) {
  return sessionID.slice(-8);
}
function numberField(value, key) {
  if (!value || typeof value !== "object")
    return;
  const field = value[key];
  return typeof field === "number" ? field : undefined;
}

// src/repo.ts
import fs2 from "fs";
import path2 from "path";

// src/crypto.ts
import crypto from "crypto";
var MAGIC = Buffer.from("OCGS1");
var NONCE_SIZE = 12;
var KEY_SIZE = 32;
var SALT_SIZE = 16;
var SCRYPT_COST = 32768;
var SCRYPT_BLOCK = 8;
var SCRYPT_PARALLEL = 1;
var SCRYPT_MAXMEM = 128 * 1024 * 1024;
var KEYCHECK_PLAINTEXT = "opencode-git-sync/keycheck/v1";
var KEYCHECK_PATH = "keycheck.ocgs";
function randomSalt() {
  return crypto.randomBytes(SALT_SIZE).toString("hex");
}
function randomRepoId() {
  return crypto.randomBytes(16).toString("hex");
}
function deriveKey(passphrase, salt) {
  return crypto.scryptSync(passphrase, salt, KEY_SIZE, {
    N: SCRYPT_COST,
    r: SCRYPT_BLOCK,
    p: SCRYPT_PARALLEL,
    maxmem: SCRYPT_MAXMEM
  });
}
function aad(repoId, relativePath) {
  return Buffer.from(`${repoId}\x00${relativePath}`, "utf8");
}
function encrypt(plaintext, key, repoId, relativePath) {
  const nonce = crypto.randomBytes(NONCE_SIZE);
  const cipher = crypto.createCipheriv("aes-256-gcm", key, nonce);
  cipher.setAAD(aad(repoId, relativePath));
  const body = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  return Buffer.concat([MAGIC, nonce, body, cipher.getAuthTag()]);
}

class DecryptError extends Error {
  constructor(message, options) {
    super(message, options);
    this.name = "DecryptError";
  }
}
function decrypt(payload, key, repoId, relativePath) {
  if (payload.length < MAGIC.length + NONCE_SIZE + 16) {
    throw new DecryptError(`\u5BC6\u6587\u957F\u5EA6\u5F02\u5E38: ${relativePath}`);
  }
  if (!payload.subarray(0, MAGIC.length).equals(MAGIC)) {
    throw new DecryptError(`\u5BC6\u6587\u683C\u5F0F\u4E0D\u5339\u914D\uFF08\u7248\u672C\u4E0D\u4E00\u81F4?\uFF09: ${relativePath}`);
  }
  const nonce = payload.subarray(MAGIC.length, MAGIC.length + NONCE_SIZE);
  const tag = payload.subarray(payload.length - 16);
  const body = payload.subarray(MAGIC.length + NONCE_SIZE, payload.length - 16);
  const decipher = crypto.createDecipheriv("aes-256-gcm", key, nonce);
  decipher.setAAD(aad(repoId, relativePath));
  decipher.setAuthTag(tag);
  try {
    return Buffer.concat([decipher.update(body), decipher.final()]);
  } catch (cause) {
    throw new DecryptError(`\u89E3\u5BC6\u5931\u8D25\uFF08passphrase \u4E0D\u5339\u914D\u6216\u5185\u5BB9\u88AB\u7BE1\u6539\uFF09: ${relativePath}`, { cause });
  }
}
function keycheck(key, repoId) {
  return encrypt(Buffer.from(KEYCHECK_PLAINTEXT, "utf8"), key, repoId, KEYCHECK_PATH);
}
function verifyKeycheck(payload, key, repoId) {
  try {
    return decrypt(payload, key, repoId, KEYCHECK_PATH).toString("utf8") === KEYCHECK_PLAINTEXT;
  } catch {
    return false;
  }
}

// src/payload.ts
import crypto2 from "crypto";
import { gunzipSync, gzipSync } from "zlib";
var WORKSPACE_PLACEHOLDER = "${WORKSPACE_ROOT}";
var PROJECT_PLACEHOLDER = "${PROJECT_DIR}";
function replaceInString(value, rules, reverse) {
  const pairs = reverse ? [
    [WORKSPACE_PLACEHOLDER, rules.worktree],
    [PROJECT_PLACEHOLDER, rules.directory]
  ] : [
    [rules.worktree, WORKSPACE_PLACEHOLDER],
    [rules.directory, PROJECT_PLACEHOLDER]
  ];
  pairs.sort((a, b) => b[0].length - a[0].length);
  let result = value;
  for (const [from, to] of pairs) {
    if (!from)
      continue;
    result = result.split(from).join(to);
  }
  return result;
}
function mapStrings(value, rules, write2) {
  if (typeof value === "string")
    return replaceInString(value, rules, !write2);
  if (Array.isArray(value))
    return value.map((item) => mapStrings(item, rules, write2));
  if (value && typeof value === "object") {
    const out = {};
    for (const [key, item] of Object.entries(value)) {
      out[key] = mapStrings(item, rules, write2);
    }
    return out;
  }
  return value;
}
function normalize(value, rules) {
  return mapStrings(value, rules, true);
}
function denormalize(value, rules) {
  return mapStrings(value, rules, false);
}
function sha256(value) {
  return crypto2.createHash("sha256").update(typeof value === "string" ? value : JSON.stringify(value)).digest("hex");
}
function toSessionMeta(info) {
  const meta = {
    id: info.id,
    title: typeof info.title === "string" ? info.title : "Untitled session",
    time: {
      created: numberOr(info.time?.created, Date.now()),
      updated: numberOr(info.time?.updated, Date.now())
    }
  };
  if (typeof info["slug"] === "string")
    meta.slug = info["slug"];
  if (typeof info.parentID === "string")
    meta.parentID = info.parentID;
  if (typeof info["version"] === "string")
    meta.version = info["version"];
  if (typeof info["agent"] === "string")
    meta.agent = info["agent"];
  if (info["model"] !== undefined)
    meta.model = info["model"];
  if (typeof info["cost"] === "number")
    meta.cost = info["cost"];
  if (info["tokens"] !== undefined)
    meta.tokens = info["tokens"];
  if (info["summary"] !== undefined)
    meta.summary = info["summary"];
  return meta;
}
function numberOr(value, fallback) {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}
function toMessagePayload(message) {
  return { info: message.info, parts: message.parts };
}
function sessionMetaPath(sessionID) {
  return `sessions/${sessionID}/meta.ocgs`;
}
function parseSessionPath(filePath) {
  const match = /^sessions\/([^/]+)\/([^/]+)\.ocgs$/.exec(filePath);
  if (!match)
    return;
  const sessionID = match[1];
  const name = match[2];
  if (name === "meta")
    return { sessionID };
  return { sessionID, messageID: name };
}
var PACK_DIR = "packs";
var PACK_BYTES = 256 * 1024;
function packPath(sessionID, seq) {
  return `sessions/${sessionID}/${PACK_DIR}/pack-${String(seq).padStart(6, "0")}.ocgs`;
}
function parsePackPath(filePath) {
  const match = /^sessions\/([^/]+)\/packs\/pack-(\d{6})\.ocgs$/.exec(filePath);
  if (!match)
    return;
  return { sessionID: match[1], seq: Number(match[2]) };
}
function messageBytes(message) {
  return Buffer.byteLength(JSON.stringify(message));
}
function encodePack(messages) {
  return gzipSync(Buffer.from(JSON.stringify({ v: 1, messages }), "utf8"));
}
function decodePack(buffer) {
  const parsed = JSON.parse(gunzipSync(buffer).toString("utf8"));
  if (parsed.v !== 1 || !Array.isArray(parsed.messages))
    throw new Error("\u5C01\u5305\u683C\u5F0F\u4E0D\u5339\u914D\uFF08\u7248\u672C\u4E0D\u4E00\u81F4?\uFF09");
  return parsed.messages;
}

// src/repo.ts
var BRANCH_PREFIX = "ocsync";
var META_FILE = "sync-meta.json";
class SyncRepo {
  options;
  constructor(options) {
    this.options = options;
  }
  get dir() {
    return this.options.dir;
  }
  branch() {
    return `${BRANCH_PREFIX}/${this.options.machine}`;
  }
  exists() {
    return fs2.existsSync(path2.join(this.options.dir, ".git"));
  }
  async ensure() {
    const { dir, remote, timeoutMs } = this.options;
    if (!this.exists()) {
      fs2.mkdirSync(dir, { recursive: true });
      await gitOrThrow(["init", "-q", "-b", this.branch()], { cwd: dir, timeoutMs });
    }
    const remotes = await git(["remote"], { cwd: dir, timeoutMs });
    const hasOrigin = remotes.stdout.split(`
`).includes("origin");
    if (!hasOrigin) {
      await gitOrThrow(["remote", "add", "origin", remote], { cwd: dir, timeoutMs });
    } else {
      await git(["remote", "set-url", "origin", remote], { cwd: dir, timeoutMs });
    }
    await gitOrThrow(["config", "remote.origin.fetch", `+refs/heads/${BRANCH_PREFIX}/*:refs/remotes/origin/${BRANCH_PREFIX}/*`], {
      cwd: dir,
      timeoutMs
    });
    await gitOrThrow(["config", "user.name", "opencode-git-sync"], { cwd: dir, timeoutMs });
    await gitOrThrow(["config", "user.email", "opencode-git-sync@localhost"], { cwd: dir, timeoutMs });
    await gitOrThrow(["config", "commit.gpgsign", "false"], { cwd: dir, timeoutMs });
    const head = await git(["rev-parse", "--verify", "HEAD"], { cwd: dir, timeoutMs });
    if (head.code !== 0) {
      await gitOrThrow(["commit", "-q", "--allow-empty", "-m", "opencode-git-sync: init"], { cwd: dir, timeoutMs });
    }
    await git(["checkout", "-q", "-B", this.branch()], { cwd: dir, timeoutMs });
  }
  async readMeta() {
    const file = path2.join(this.options.dir, META_FILE);
    try {
      const raw = await Bun.file(file).text();
      const parsed = JSON.parse(raw);
      if (typeof parsed.repoId !== "string" || typeof parsed.salt !== "string")
        return;
      return {
        version: 1,
        repoId: parsed.repoId,
        salt: parsed.salt,
        machines: Array.isArray(parsed.machines) ? parsed.machines : [],
        createdAt: typeof parsed.createdAt === "number" ? parsed.createdAt : Date.now()
      };
    } catch {
      return;
    }
  }
  async writeMeta(meta) {
    fs2.mkdirSync(this.options.dir, { recursive: true });
    await Bun.write(path2.join(this.options.dir, META_FILE), JSON.stringify(meta, null, 2));
  }
  static newMeta(machine) {
    return {
      version: 1,
      repoId: randomRepoId(),
      salt: randomSalt(),
      machines: [machine],
      createdAt: Date.now()
    };
  }
  async readLocalFile(file) {
    try {
      const target = path2.join(this.options.dir, file);
      if (!fs2.existsSync(target))
        return;
      return Buffer.from(await Bun.file(target).arrayBuffer());
    } catch {
      return;
    }
  }
  async writeFiles(files) {
    for (const file of files) {
      const target = path2.join(this.options.dir, file.path);
      fs2.mkdirSync(path2.dirname(target), { recursive: true });
      await Bun.write(target, file.content);
    }
  }
  async removeFiles(files) {
    for (const file of files) {
      try {
        fs2.rmSync(path2.join(this.options.dir, file), { force: true });
      } catch {}
    }
  }
  async listSessionIDs() {
    const dir = path2.join(this.options.dir, "sessions");
    try {
      return fs2.readdirSync(dir, { withFileTypes: true }).filter((entry) => entry.isDirectory()).map((entry) => entry.name);
    } catch {
      return [];
    }
  }
  async listLegacyMessageFiles(sessionID) {
    const dir = path2.join(this.options.dir, "sessions", sessionID);
    try {
      return fs2.readdirSync(dir).filter((name) => name.endsWith(".ocgs") && name !== "meta.ocgs").map((name) => `sessions/${sessionID}/${name}`);
    } catch {
      return [];
    }
  }
  async listPackFiles(sessionID) {
    const dir = path2.join(this.options.dir, "sessions", sessionID, PACK_DIR);
    let entries;
    try {
      entries = fs2.readdirSync(dir);
    } catch {
      return [];
    }
    return entries.map((name) => /^pack-(\d{6})\.ocgs$/.exec(name)).filter((match) => match !== null).map((match) => ({ seq: Number(match[1]), path: packPath(sessionID, Number(match[1])) })).sort((a, b) => a.seq - b.seq);
  }
  async hasChanges() {
    const status = await git(["status", "--porcelain"], { cwd: this.options.dir, timeoutMs: this.options.timeoutMs });
    return status.stdout.trim().length > 0;
  }
  async commit(message) {
    const { dir, timeoutMs } = this.options;
    await gitOrThrow(["add", "-A"], { cwd: dir, timeoutMs });
    const status = await git(["status", "--porcelain"], { cwd: dir, timeoutMs });
    if (status.stdout.trim().length === 0)
      return;
    await gitOrThrow(["commit", "-q", "--amend", "-m", message], { cwd: dir, timeoutMs });
  }
  async push() {
    const { dir, timeoutMs } = this.options;
    const result = await git(["push", "--force", "origin", this.branch()], { cwd: dir, timeoutMs: timeoutMs * 2 });
    if (result.code !== 0) {
      log.warn(`push \u5931\u8D25: ${result.stderr.trim() || result.stdout.trim()}`);
      return false;
    }
    return true;
  }
  async fetch() {
    const { dir, timeoutMs } = this.options;
    const result = await git(["fetch", "origin", "--prune", "--no-write-fetch-head"], {
      cwd: dir,
      timeoutMs
    });
    if (result.code !== 0) {
      log.warn(`fetch \u5931\u8D25: ${result.stderr.trim() || result.stdout.trim()}`);
      return false;
    }
    return true;
  }
  async readRemoteFiles() {
    const { dir, timeoutMs } = this.options;
    const branches = await this.remoteBranches();
    const output = new Map;
    for (const branch of branches) {
      const ref = `origin/${branch}`;
      const listing = await git(["ls-tree", "-r", ref], { cwd: dir, timeoutMs });
      if (listing.code !== 0)
        continue;
      const entries = [];
      for (const line of listing.stdout.split(`
`)) {
        if (!line.trim())
          continue;
        const match = /^(\d+)\s+(\w+)\s+([0-9a-f]+)\t(.+)$/.exec(line);
        if (!match)
          continue;
        entries.push({ sha: match[3], path: match[4] });
      }
      const blobs = await readBlobs(entries.map((entry) => entry.sha), { cwd: dir, timeoutMs: timeoutMs * 3 });
      const files = new Map;
      for (const entry of entries) {
        const blob = blobs.get(entry.sha);
        if (blob)
          files.set(entry.path, blob);
      }
      output.set(branch, files);
    }
    return output;
  }
  async remoteBranches() {
    const { dir, timeoutMs } = this.options;
    const result = await git(["for-each-ref", "--format=%(refname:short)", `refs/remotes/origin/${BRANCH_PREFIX}`], { cwd: dir, timeoutMs });
    if (result.code !== 0)
      return [];
    return result.stdout.split(`
`).map((line) => line.trim()).filter((line) => line.startsWith(`origin/${BRANCH_PREFIX}/`)).map((line) => line.replace(/^origin\//, ""));
  }
}

// src/state.ts
import { Database as Database2 } from "bun:sqlite";
import crypto3 from "crypto";
import fs3 from "fs";
import path3 from "path";
class State {
  db;
  dbPath;
  constructor(file = stateDbPath()) {
    this.dbPath = file;
    fs3.mkdirSync(path3.dirname(file), { recursive: true });
    this.db = new Database2(file, { create: true });
    this.db.run("PRAGMA journal_mode = WAL;");
    this.db.run("PRAGMA busy_timeout = 5000;");
    this.db.run(`CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);`);
    this.db.run(`CREATE TABLE IF NOT EXISTS message_fingerprint (session_id TEXT NOT NULL, message_id TEXT NOT NULL, hash TEXT NOT NULL, PRIMARY KEY (session_id, message_id));`);
    this.db.run(`CREATE TABLE IF NOT EXISTS session_fingerprint (session_id TEXT PRIMARY KEY, hash TEXT NOT NULL);`);
  }
  get(key) {
    const row = this.db.query("SELECT value FROM meta WHERE key = ?").get(key);
    return row?.value;
  }
  set(key, value) {
    this.db.query("INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value").run(key, value);
  }
  machineID() {
    const existing = this.get("machine_id");
    if (existing)
      return existing;
    const generated = `${osHostname()}-${crypto3.randomBytes(3).toString("hex")}`;
    this.set("machine_id", generated);
    return generated;
  }
  repoId() {
    return this.get("repo_id");
  }
  setRepoId(value) {
    this.set("repo_id", value);
  }
  salt() {
    return this.get("salt");
  }
  setSalt(value) {
    this.set("salt", value);
  }
  lastSyncAt() {
    const value = this.get("last_sync_at");
    return value ? Number(value) : undefined;
  }
  setLastSyncAt(value) {
    this.set("last_sync_at", String(value));
  }
  messageHash(sessionID, messageID) {
    const row = this.db.query("SELECT hash FROM message_fingerprint WHERE session_id = ? AND message_id = ?").get(sessionID, messageID);
    return row?.hash;
  }
  setMessageHash(sessionID, messageID, hash) {
    this.db.query("INSERT INTO message_fingerprint (session_id, message_id, hash) VALUES (?, ?, ?) ON CONFLICT(session_id, message_id) DO UPDATE SET hash = excluded.hash").run(sessionID, messageID, hash);
  }
  sessionHash(sessionID) {
    const row = this.db.query("SELECT hash FROM session_fingerprint WHERE session_id = ?").get(sessionID);
    return row?.hash;
  }
  setSessionHash(sessionID, hash) {
    this.db.query("INSERT INTO session_fingerprint (session_id, hash) VALUES (?, ?) ON CONFLICT(session_id) DO UPDATE SET hash = excluded.hash").run(sessionID, hash);
  }
  close() {
    try {
      this.db.close();
    } catch {}
  }
}
function osHostname() {
  try {
    return __require("os").hostname().split(".")[0] ?? "machine";
  } catch {
    return "machine";
  }
}

// src/snapshot.ts
async function captureSession(client, sessionID, rules) {
  const session = await client.session.get({ path: { id: sessionID } });
  const info = session.data;
  if (!info)
    return;
  const meta = toSessionMeta(info);
  const response = await client.session.messages({ path: { id: sessionID } });
  const messages = (response.data ?? []).map((message) => toMessagePayload(message));
  return {
    meta: normalize(meta, rules),
    messages: messages.map((message) => normalize(message, rules))
  };
}

// src/sync.ts
class SyncService {
  deps;
  key;
  repoMeta;
  pending = new Set;
  lastFetchAt = 0;
  disposed = false;
  timer;
  pushing = false;
  lock = Promise.resolve();
  constructor(deps) {
    this.deps = deps;
  }
  withLock(task) {
    const run = this.lock.then(task, task);
    this.lock = run.then(() => {
      return;
    }, () => {
      return;
    });
    return run;
  }
  cachedMeta() {
    const repoId = this.deps.state.repoId();
    const salt = this.deps.state.salt();
    if (!repoId || !salt)
      return;
    return {
      version: 1,
      repoId,
      salt,
      machines: [],
      createdAt: Date.now()
    };
  }
  rememberMeta(meta) {
    this.deps.state.setRepoId(meta.repoId);
    this.deps.state.setSalt(meta.salt);
    this.repoMeta = meta;
  }
  contentKey(salt) {
    if (!this.key)
      this.key = deriveKey(this.deps.passphrase, salt);
    return this.key;
  }
  async prepare() {
    try {
      await this.deps.repo.ensure();
      const existing = await this.deps.repo.readMeta();
      if (existing) {
        this.rememberMeta(existing);
        return;
      }
      const cached = this.cachedMeta();
      if (cached)
        this.rememberMeta(cached);
    } catch (error) {
      log.warn(`\u51C6\u5907\u540C\u6B65\u4ED3\u5E93\u5931\u8D25: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
  async adoptMeta(meta) {
    const changed = !this.repoMeta || this.repoMeta.repoId !== meta.repoId;
    this.rememberMeta(meta);
    if (!changed)
      return;
    await this.deps.repo.writeMeta(meta);
    await this.deps.repo.writeFiles([
      { path: KEYCHECK_PATH, content: keycheck(this.contentKey(meta.salt), meta.repoId) }
    ]);
    log.info("\u5DF2\u7EE7\u627F\u8FDC\u7AEF\u540C\u6B65\u4ED3\u5E93\u5143\u4FE1\u606F");
  }
  async ensureMeta() {
    const existing = this.repoMeta ?? this.cachedMeta();
    if (existing) {
      this.rememberMeta(existing);
      return existing;
    }
    const meta = SyncRepo.newMeta(this.deps.machine);
    this.rememberMeta(meta);
    await this.deps.repo.writeMeta(meta);
    await this.deps.repo.writeFiles([
      { path: KEYCHECK_PATH, content: keycheck(this.contentKey(meta.salt), meta.repoId) }
    ]);
    return meta;
  }
  dispose() {
    this.disposed = true;
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = undefined;
    }
    this.pending.clear();
  }
  async pull(db) {
    if (this.disposed)
      return { sessions: 0, messages: 0, skipped: true, changed: [] };
    const fetched = await this.deps.repo.fetch();
    if (!fetched)
      return { sessions: 0, messages: 0, skipped: true, changed: [] };
    this.lastFetchAt = Date.now();
    const branches = await this.deps.repo.readRemoteFiles();
    const remoteMeta = findRemoteMeta(branches);
    if (remoteMeta) {
      if (this.repoMeta && this.repoMeta.repoId !== remoteMeta.repoId) {
        log.warn(`\u8FDC\u7AEF\u4ED3\u5E93 ID \u4E0D\u4E00\u81F4\uFF08\u672C\u5730 ${this.repoMeta.repoId} / \u8FDC\u7AEF ${remoteMeta.repoId}\uFF09\uFF0C\u8DF3\u8FC7\u5BFC\u5165\uFF1B` + `\u5982\u9700\u6539\u7528\u8BE5\u8FDC\u7AEF\uFF0C\u8BF7\u6E05\u7A7A ${this.deps.state.dbPath} \u540E\u91CD\u8BD5`);
        return { sessions: 0, messages: 0, skipped: true, changed: [] };
      }
      await this.adoptMeta(remoteMeta);
    } else {
      await this.ensureMeta();
    }
    const effective = this.repoMeta;
    if (!effective)
      return { sessions: 0, messages: 0, skipped: true, changed: [] };
    if (branches.size === 0)
      return { sessions: 0, messages: 0, skipped: false, changed: [] };
    const key = this.contentKey(effective.salt);
    for (const files of branches.values()) {
      const check = files.get(KEYCHECK_PATH);
      if (!check)
        continue;
      if (!verifyKeycheck(check, key, effective.repoId)) {
        log.error("passphrase \u4E0D\u5339\u914D\uFF0C\u5DF2\u4E2D\u6B62\u540C\u6B65\uFF08\u4E0D\u4F1A\u63A8\u9001\u4EFB\u4F55\u6570\u636E\uFF09");
        return { sessions: 0, messages: 0, skipped: true, changed: [] };
      }
      break;
    }
    if (!db)
      return { sessions: 0, messages: 0, skipped: true, changed: [] };
    let sessions = 0;
    let messages = 0;
    const changed = [];
    for (const [branch, files] of branches) {
      const metas = new Map;
      const payloads = new Map;
      for (const filePath of [...files.keys()].sort()) {
        const blob = files.get(filePath);
        const pack = parsePackPath(filePath);
        const parsed = pack ? undefined : parseSessionPath(filePath);
        if (!pack && !parsed)
          continue;
        let plain;
        try {
          plain = decrypt(blob, key, effective.repoId, filePath);
        } catch (error) {
          log.warn(`\u8DF3\u8FC7\u65E0\u6CD5\u89E3\u5BC6\u7684\u6587\u4EF6 ${branch}:${filePath} (${error instanceof Error ? error.message : String(error)})`);
          continue;
        }
        if (pack) {
          let packed;
          try {
            packed = decodePack(plain);
          } catch (error) {
            log.warn(`\u8DF3\u8FC7\u65E0\u6CD5\u89E3\u6790\u7684\u5C01\u5305 ${branch}:${filePath} (${error instanceof Error ? error.message : String(error)})`);
            continue;
          }
          const list = payloads.get(pack.sessionID) ?? [];
          for (const message of packed)
            list.push(denormalize(message, this.deps.rules));
          payloads.set(pack.sessionID, list);
          continue;
        }
        if (!parsed)
          continue;
        const value = denormalize(JSON.parse(plain.toString("utf8")), this.deps.rules);
        if (parsed.messageID === undefined) {
          metas.set(parsed.sessionID, value);
        } else {
          const list = payloads.get(parsed.sessionID) ?? [];
          list.push(value);
          payloads.set(parsed.sessionID, list);
        }
      }
      db.transaction(() => {
        for (const [sessionID, sessionMeta] of metas) {
          const updated = db.upsertSession(sessionMeta, this.deps.scope);
          if (updated)
            changed.push(sessionID);
          sessions += 1;
        }
        for (const [sessionID, list] of payloads) {
          for (const message of list) {
            if (db.upsertMessage(sessionID, message.info, message.parts))
              messages += 1;
          }
        }
      });
    }
    this.deps.state.setLastSyncAt(Date.now());
    return { sessions, messages, skipped: false, changed };
  }
  async notifyChanged(sessionIDs) {
    for (const sessionID of sessionIDs) {
      try {
        const result = await this.deps.client.session.get({ path: { id: sessionID } });
        const title = result.data?.title;
        if (!title)
          continue;
        await this.deps.client.session.update({ path: { id: sessionID }, body: { title } });
      } catch {}
    }
  }
  async stage(sessionID) {
    if (this.disposed)
      return false;
    return this.withLock(() => this.stageUnlocked(sessionID));
  }
  async stageUnlocked(sessionID) {
    const meta = await this.ensureMeta();
    if (!meta)
      return false;
    const snapshot = await captureSession(this.deps.client, sessionID, this.deps.rules);
    if (!snapshot)
      return false;
    const key = this.contentKey(meta.salt);
    const files = [];
    const staged = [];
    const metaHash = sha256(snapshot.meta);
    if (this.deps.state.sessionHash(sessionID) !== metaHash) {
      const path4 = sessionMetaPath(sessionID);
      files.push({ path: path4, content: encrypt(Buffer.from(JSON.stringify(snapshot.meta)), key, meta.repoId, path4) });
    }
    for (const message of snapshot.messages) {
      if (this.deps.state.messageHash(sessionID, message.info.id) === sha256(message))
        continue;
      staged.push(message);
    }
    if (staged.length > 0)
      files.push(...await this.appendToPacks(sessionID, staged, key, meta.repoId));
    if (files.length === 0)
      return false;
    await this.deps.repo.writeFiles(files);
    if (this.deps.state.sessionHash(sessionID) !== metaHash)
      this.deps.state.setSessionHash(sessionID, metaHash);
    for (const message of staged)
      this.deps.state.setMessageHash(sessionID, message.info.id, sha256(message));
    log.info(`\u5DF2\u6682\u5B58\u4F1A\u8BDD ${sessionID}\uFF1A${staged.length} \u6761\u6D88\u606F\uFF08${files.length} \u4E2A\u6587\u4EF6\uFF09`);
    return true;
  }
  async appendToPacks(sessionID, incoming, key, repoId) {
    const packs = await this.deps.repo.listPackFiles(sessionID);
    let seq = packs.at(-1)?.seq ?? 0;
    let open = seq > 0;
    let entries = [];
    let size = 0;
    if (open) {
      const current = packPath(sessionID, seq);
      const blob = await this.deps.repo.readLocalFile(current);
      if (!blob) {
        open = false;
        seq = 0;
      } else {
        entries = decodePack(decrypt(blob, key, repoId, current));
        size = entries.reduce((total, entry) => total + messageBytes(entry), 0);
        if (size >= PACK_BYTES) {
          open = false;
          entries = [];
          size = 0;
        }
      }
    }
    const files = [];
    const write2 = () => {
      if (entries.length === 0)
        return;
      if (!open) {
        seq += 1;
        open = true;
      }
      const path4 = packPath(sessionID, seq);
      files.push({ path: path4, content: encrypt(encodePack(entries), key, repoId, path4) });
    };
    for (const message of incoming) {
      const index = entries.findIndex((entry) => entry.info.id === message.info.id);
      if (index >= 0) {
        size += messageBytes(message) - messageBytes(entries[index]);
        entries[index] = message;
        continue;
      }
      const addition = messageBytes(message);
      if (entries.length > 0 && size + addition > PACK_BYTES) {
        write2();
        open = false;
        entries = [];
        size = 0;
      }
      entries.push(message);
      size += addition;
    }
    write2();
    return files;
  }
  async migrateLegacy() {
    if (this.disposed)
      return;
    await this.withLock(async () => {
      const meta = this.repoMeta ?? this.cachedMeta();
      if (!meta)
        return;
      const key = this.contentKey(meta.salt);
      let changed = false;
      for (const sessionID of await this.deps.repo.listSessionIDs()) {
        const legacy = await this.deps.repo.listLegacyMessageFiles(sessionID);
        if (legacy.length === 0)
          continue;
        const messages = [];
        const migrated = [];
        for (const filePath of legacy) {
          const blob = await this.deps.repo.readLocalFile(filePath);
          if (!blob)
            continue;
          try {
            messages.push(JSON.parse(decrypt(blob, key, meta.repoId, filePath).toString("utf8")));
            migrated.push(filePath);
          } catch (error) {
            log.warn(`\u8FC1\u79FB\u65F6\u8DF3\u8FC7\u65E0\u6CD5\u89E3\u5BC6\u7684\u6587\u4EF6 ${filePath} (${error instanceof Error ? error.message : String(error)})`);
          }
        }
        if (messages.length === 0)
          continue;
        messages.sort((a, b) => (a.info.time?.created ?? 0) - (b.info.time?.created ?? 0) || a.info.id.localeCompare(b.info.id));
        const packs = await this.buildPacks(sessionID, messages, key, meta.repoId);
        await this.deps.repo.writeFiles(packs);
        await this.deps.repo.removeFiles(migrated);
        changed = true;
        log.info(`\u5DF2\u5408\u5E76\u4F1A\u8BDD ${sessionID}\uFF1A${messages.length} \u6761\u6D88\u606F \u2192 ${packs.length} \u4E2A\u5C01\u5305`);
      }
      if (changed)
        await this.push();
    });
  }
  async buildPacks(sessionID, messages, key, repoId) {
    const existing = await this.deps.repo.listPackFiles(sessionID);
    let seq = existing.at(-1)?.seq ?? 0;
    const files = [];
    let entries = [];
    let size = 0;
    const flush = () => {
      if (entries.length === 0)
        return;
      seq += 1;
      const path4 = packPath(sessionID, seq);
      files.push({ path: path4, content: encrypt(encodePack(entries), key, repoId, path4) });
      entries = [];
      size = 0;
    };
    for (const message of messages) {
      const addition = messageBytes(message);
      if (entries.length > 0 && size + addition > PACK_BYTES)
        flush();
      entries.push(message);
      size += addition;
    }
    flush();
    return files;
  }
  async push() {
    if (this.pushing)
      return false;
    this.pushing = true;
    try {
      const meta = await this.ensureMeta();
      if (!meta)
        return false;
      await this.deps.repo.writeMeta(meta);
      const key = this.contentKey(meta.salt);
      const existing = await this.deps.repo.readLocalFile(KEYCHECK_PATH);
      if (!existing || !verifyKeycheck(existing, key, meta.repoId)) {
        await this.deps.repo.writeFiles([{ path: KEYCHECK_PATH, content: keycheck(key, meta.repoId) }]);
      }
      const changed = await this.deps.repo.hasChanges();
      if (!changed) {
        log.warn("\u6CA1\u6709\u5F85\u63A8\u9001\u5185\u5BB9\uFF0C\u8DF3\u8FC7 push\uFF08\u82E5\u8FDC\u7AEF\u5206\u652F\u662F\u7A7A\u7684\uFF0C\u8BF4\u660E\u672C\u673A\u8FD8\u6CA1\u6210\u529F\u6682\u5B58\u8FC7\u4F1A\u8BDD\uFF09");
        return false;
      }
      await this.deps.repo.commit(`opencode-git-sync ${new Date().toISOString()}`);
      const pushed = await this.deps.repo.push();
      if (pushed)
        log.info(`\u5DF2\u63A8\u9001\u5230 ${this.deps.repo.branch()}`);
      return pushed;
    } catch (error) {
      log.warn(`\u63A8\u9001\u5931\u8D25: ${error instanceof Error ? error.message : String(error)}`);
      return false;
    } finally {
      this.pushing = false;
    }
  }
  schedule(sessionID, debounceMs) {
    if (this.disposed)
      return;
    this.pending.add(sessionID);
    if (this.timer)
      clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      this.flush();
    }, debounceMs);
  }
  async flush() {
    if (this.disposed)
      return;
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = undefined;
    }
    const sessions = [...this.pending];
    this.pending.clear();
    if (sessions.length === 0)
      return;
    try {
      await this.withLock(async () => {
        if (this.disposed)
          return;
        for (const sessionID of sessions)
          await this.stageUnlocked(sessionID);
        await this.push();
      });
    } catch (error) {
      log.warn(`\u540C\u6B65\u63A8\u9001\u5F02\u5E38: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
}
function findRemoteMeta(branches) {
  for (const files of branches.values()) {
    const raw = files.get(META_FILE);
    if (!raw)
      continue;
    try {
      const parsed = JSON.parse(raw.toString("utf8"));
      if (typeof parsed.repoId !== "string" || typeof parsed.salt !== "string")
        continue;
      return {
        version: 1,
        repoId: parsed.repoId,
        salt: parsed.salt,
        machines: Array.isArray(parsed.machines) ? parsed.machines : [],
        createdAt: typeof parsed.createdAt === "number" ? parsed.createdAt : Date.now()
      };
    } catch {
      continue;
    }
  }
  return;
}

// src/index.ts
var DEFAULTS = {
  debounceMs: 3000,
  syncTimeoutMs: 5000,
  gitTimeoutMs: 30000
};
function readPassphraseFile(file, quiet = false) {
  try {
    const expanded = file.startsWith("~/") ? path4.join(os2.homedir(), file.slice(2)) : file;
    const content = fs4.readFileSync(expanded, "utf8").trim();
    return content.length > 0 ? content : undefined;
  } catch {
    if (!quiet)
      log.warn(`\u8BFB\u53D6\u53E3\u4EE4\u6587\u4EF6\u5931\u8D25: ${file}`);
    return;
  }
}
function readOptions(options) {
  const source = options ?? {};
  return {
    remote: source.remote ?? process.env["OPENCODE_GIT_SYNC_REMOTE"],
    passphrase: source.passphrase ?? (source.passphraseFile ? readPassphraseFile(source.passphraseFile) : undefined) ?? process.env["OPENCODE_GIT_SYNC_PASSPHRASE"] ?? firstExisting(defaultPassphraseFiles()),
    machine: source.machine ?? process.env["OPENCODE_GIT_SYNC_MACHINE"],
    debounceMs: source.debounceMs ?? DEFAULTS.debounceMs,
    syncTimeoutMs: source.syncTimeoutMs ?? DEFAULTS.syncTimeoutMs,
    gitTimeoutMs: source.gitTimeoutMs ?? DEFAULTS.gitTimeoutMs,
    enabled: source.enabled ?? true
  };
}
function firstExisting(files) {
  for (const file of files) {
    const value = readPassphraseFile(file, true);
    if (value)
      return value;
  }
  return;
}
async function withTimeout(task, ms) {
  let timer;
  try {
    return await Promise.race([
      task,
      new Promise((resolve) => {
        timer = setTimeout(() => resolve(undefined), ms);
      })
    ]);
  } finally {
    if (timer)
      clearTimeout(timer);
  }
}
var GitSync = async (input, options) => {
  setStateDir(projectStateDir(input.worktree));
  const config = readOptions(options);
  if (config.enabled === false)
    return {};
  const remote = config.remote ?? await detectRemote(input.worktree, config.gitTimeoutMs ?? DEFAULTS.gitTimeoutMs);
  if (!remote) {
    log.warn("\u9879\u76EE\u4ED3\u5E93\u6CA1\u6709\u53EF\u7528\u8FDC\u7AEF\uFF0C\u63D2\u4EF6\u4E0D\u542F\u7528");
    return {};
  }
  if (!config.passphrase) {
    log.warn(`\u672A\u627E\u5230 passphrase\uFF0C\u63D2\u4EF6\u4E0D\u542F\u7528\uFF08\u4F1A\u8BDD\u5185\u5BB9\u5FC5\u987B\u52A0\u5BC6\uFF09\u3002\u8BF7\u521B\u5EFA ${defaultPassphraseFiles()[0]} \u6216\u8BBE\u7F6E OPENCODE_GIT_SYNC_PASSPHRASE`);
    return {};
  }
  const state = new State(stateDbPath());
  const machine = config.machine ?? state.machineID();
  const repo = new SyncRepo({
    dir: repoDir(),
    remote,
    machine,
    timeoutMs: config.gitTimeoutMs ?? DEFAULTS.gitTimeoutMs
  });
  const rules = { worktree: input.worktree, directory: input.directory };
  const scope = {
    projectID: input.project.id,
    directory: input.directory,
    path: path4.relative(path4.resolve(input.worktree), path4.resolve(input.directory)).replaceAll("\\", "/")
  };
  const service = new SyncService({
    repo,
    state,
    client: input.client,
    rules,
    scope,
    passphrase: config.passphrase,
    machine,
    timeoutMs: config.gitTimeoutMs ?? DEFAULTS.gitTimeoutMs
  });
  await service.prepare();
  const syncTask = (async () => {
    const file = await findOpencodeDb();
    if (!file) {
      log.warn("\u672A\u627E\u5230 opencode \u6570\u636E\u5E93\uFF0C\u672C\u6B21\u4E0D\u540C\u6B65");
      await service.migrateLegacy();
      return;
    }
    const db = new OpencodeDb(file);
    let result;
    try {
      result = await service.pull(db);
      if (result.changed.length > 0)
        await service.notifyChanged(result.changed);
    } finally {
      db.close();
    }
    await service.migrateLegacy();
    return result;
  })();
  const budget = config.syncTimeoutMs ?? DEFAULTS.syncTimeoutMs;
  const pulled = await withTimeout(syncTask, budget);
  if (pulled) {
    log.info(`\u9996\u5C4F\u540C\u6B65\u5B8C\u6210\uFF1A\u4F1A\u8BDD ${pulled.sessions}\uFF0C\u6D88\u606F ${pulled.messages}`);
  } else {
    log.warn(`\u9996\u5C4F\u540C\u6B65\u672A\u5728 ${budget}ms \u5185\u5B8C\u6210\uFF0C\u8F6C\u5165\u540E\u53F0\u7EE7\u7EED\uFF08\u5B8C\u6210\u540E\u81EA\u52A8\u5237\u65B0\u4F1A\u8BDD\u5217\u8868\uFF09`);
    syncTask.then((result) => {
      if (!result)
        return;
      log.info(`\u540E\u53F0\u540C\u6B65\u5B8C\u6210\uFF1A\u4F1A\u8BDD ${result.sessions}\uFF0C\u6D88\u606F ${result.messages}`);
    }).catch((error) => {
      log.warn(`\u540E\u53F0\u540C\u6B65\u5931\u8D25: ${error instanceof Error ? error.message : String(error)}`);
    });
  }
  return {
    event: async ({ event }) => {
      if (event.type !== "session.idle")
        return;
      const sessionID = event.properties?.["sessionID"];
      if (typeof sessionID !== "string")
        return;
      try {
        const staged = await service.stage(sessionID);
        if (!staged) {
          log.warn(`\u4F1A\u8BDD\u6682\u5B58\u4E3A\u7A7A\uFF08\u53EF\u80FD\u6CA1\u6709\u65B0\u6D88\u606F\uFF09: ${sessionID}`);
          return;
        }
        service.schedule(sessionID, config.debounceMs ?? DEFAULTS.debounceMs);
      } catch (error) {
        log.warn(`\u6682\u5B58\u4F1A\u8BDD\u5931\u8D25 ${sessionID}: ${error instanceof Error ? error.message : String(error)}`);
      }
    },
    dispose: async () => {
      try {
        await withTimeout(service.flush(), 5000);
      } catch {}
      service.dispose();
      state.close();
    }
  };
};
var src_default = GitSync;
export {
  src_default as default
};
